#include <iostream>
#include <cstdlib>
#include <ctime>
#include <sstream>
#include "STUDENTDATA.h"

std::string generateStudentId(int i) {
    std::ostringstream oss;
    oss << "23CS" << 1000 + i;
    return oss.str();
}

int main() {
    srand(static_cast<unsigned int>(time(0)));

    int n;
    std::cout << "Enter number of students: ";
    std::cin >> n;

    StudentData data(n);

    for (int i = 0; i < n; ++i) {
        data.setId(i, generateStudentId(i));
        for (int j = 0; j < 5; ++j) {
            int random_mark = rand() % 51 + 50; // [50, 100]
            data.setMark(i, j, random_mark);
        }
    }

    data.calculateTotals();

    std::cout << "\nStudent Data:\n";
    data.print();

    return 0;
}
