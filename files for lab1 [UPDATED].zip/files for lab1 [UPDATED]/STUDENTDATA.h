#ifndef STUDENTDATA_H
#define STUDENTDATA_H

#include <iostream>
#include <string>
#include <vector>
#include <array>

class StudentData {
private:
    int n;
    std::vector<std::string> ids;
    std::vector<std::array<int, 5>> marks;
    std::vector<int> totals;

public:
    StudentData(int num_students) : n(num_students) {
        ids.resize(n);
        marks.resize(n);
        totals.resize(n, 0);
    }

    void setId(int i, const std::string& id) {
        if (i >= 0 && i < n) ids[i] = id;
    }

    void setMark(int studentIndex, int subjectIndex, int mark) {
        if (studentIndex >= 0 && studentIndex < n && subjectIndex >= 0 && subjectIndex < 5)
            marks[studentIndex][subjectIndex] = mark;
    }

    void calculateTotals() {
        for (int i = 0; i < n; ++i) {
            totals[i] = 0;
            for (int j = 0; j < 5; ++j)
                totals[i] += marks[i][j];
        }
    }

    void print() const {
        for (int i = 0; i < n; ++i) {
            std::cout << "Student ID: " << ids[i] << "\nMarks: ";
            for (int j = 0; j < 5; ++j)
                std::cout << marks[i][j] << " ";
            std::cout << "\nTotal: " << totals[i] << "\n\n";
        }
    }
};

#endif // STUDENTDATA_H
