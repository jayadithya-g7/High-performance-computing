#ifndef STUDENT_H
#define STUDENT_H

#include <iostream>
#include <string>

class Student
{
private:
    std::string id;
    int marks[5];
    int total;

public:
    Student() : id(""), total(0)
    {
        for (int i = 0; i < 5; ++i)
            marks[i] = 0;
    }

    Student(const std::string &student_id) : id(student_id), total(0)
    {
        for (int i = 0; i < 5; ++i)
            marks[i] = 0;
    }

    void setId(const std::string &student_id)
    {
        id = student_id;
    }

    void setMark(int index, int mark)
    {
        if (index >= 0 && index < 5)
            marks[index] = mark;
    }

    void calculateTotal()
    {
        total = 0;
        for (int i = 0; i < 5; ++i)
            total += marks[i];
    }

    std::string getId() const { return id; }
    int getMark(int index) const { return (index >= 0 && index < 5) ? marks[index] : -1; }
    int getTotal() const { return total; }

    void print() const
    {
        std::cout << "Student ID: " << id << "\nMarks: ";
        for (int i = 0; i < 5; ++i)
            std::cout << marks[i] << " ";
        std::cout << "\nTotal: " << total << "\n\n";
    }
};

#endif // STUDENT_H
