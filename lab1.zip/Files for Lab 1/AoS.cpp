#include <iostream>
#include <cstdlib>
#include <ctime>
#include <sstream>
#include "Student.h"

std::string generateStudentId(int i)
{
    std::ostringstream oss;
    oss << "23CS" << 1000 + i;
    return oss.str();
}

int main()
{
    srand(static_cast<unsigned int>(time(0)));

    int n;
    std::cout << "Enter number of students: ";
    std::cin >> n;

    Student *students = new Student[n];

    for (int i = 0; i < n; ++i)
    {
        std::string sid = generateStudentId(i);
        students[i].setId(sid);

        for (int j = 0; j < 5; ++j)
        {
            int random_mark = rand() % 51 + 50; // Marks between 50 and 100
            students[i].setMark(j, random_mark);
        }

        students[i].calculateTotal();
    }

    std::cout << "\nStudent Data:\n";
    for (int i = 0; i < n; ++i)
    {
        students[i].print();
    }

    delete[] students;
    return 0;
}
